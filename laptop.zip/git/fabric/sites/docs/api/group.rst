==============
``group``
==============

.. automodule:: fabric.group
