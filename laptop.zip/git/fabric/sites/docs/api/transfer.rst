============
``transfer``
============

.. automodule:: fabric.transfer
    :member-order: bysource
