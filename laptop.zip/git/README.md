 * airfow: job scheduler using DAG concepts to replace Control-M 
 * ansible-os-hardening: playbooks and test-kitchen for 4 Linux flavors
 * bin: includes all bash scripts to govern/administer K8s, helm, airflow, misp, etc. in Ubuntu 18.04 laptop
 * etc: includes config file of the kube-cluster master-node (with 2 worker-nodes) of Ubuntu 18.04 laptop
 * fabric: Python Fabric framework for remote control of Linux nodes (useful to build OS monitors and CICD tooling/dashboard)
 * kube-cluster: includes ansible-playbooks to add worker-nodes and to add persistent volumes, etc.
 * superset: powerful visual analytics having many plugins including elasticsearch, etc.
